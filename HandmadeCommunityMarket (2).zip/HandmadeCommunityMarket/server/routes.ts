import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { setupAuth } from "./auth";
import { setupWebsocket } from "./websocket";
import { storage } from "./storage";
import { insertBookingSchema, insertFavoriteSchema, insertRatingSchema, type Rating } from "@shared/schema";
import { ZodError } from "zod";

// Middleware to check if user is authenticated
const isAuthenticated = (req: Request, res: Response, next: Function) => {
  if (req.isAuthenticated()) {
    return next();
  }
  res.status(401).json({ message: "Unauthorized" });
};

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup authentication routes
  setupAuth(app);

  // API routes
  // Get study spaces
  app.get("/api/spaces", async (req, res, next) => {
    try {
      const type = req.query.type as string | undefined;
      
      if (type) {
        const spaces = await storage.getSpacesByType(type);
        res.json(spaces);
      } else {
        const spaces = await storage.getSpaces();
        res.json(spaces);
      }
    } catch (error) {
      next(error);
    }
  });

  // Get specific study space
  app.get("/api/spaces/:id", async (req, res, next) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid space ID" });
      }
      
      const space = await storage.getSpaceById(id);
      if (!space) {
        return res.status(404).json({ message: "Space not found" });
      }
      
      res.json(space);
    } catch (error) {
      next(error);
    }
  });

  // Get user bookings
  app.get("/api/bookings", isAuthenticated, async (req, res, next) => {
    try {
      const userId = req.user!.id;
      const bookings = await storage.getBookings(userId);
      
      // Enhance bookings with space details
      const enhancedBookings = await Promise.all(bookings.map(async (booking) => {
        const space = await storage.getSpaceById(booking.spaceId);
        return {
          ...booking,
          space
        };
      }));
      
      res.json(enhancedBookings);
    } catch (error) {
      next(error);
    }
  });

  // Create a booking
  app.post("/api/bookings", isAuthenticated, async (req, res, next) => {
    try {
      const userId = req.user!.id;
      
      // Validate request body
      try {
        const bookingData = insertBookingSchema.parse({
          ...req.body,
          userId
        });
        
        // Check if space exists and has availability
        const space = await storage.getSpaceById(bookingData.spaceId);
        if (!space) {
          return res.status(404).json({ message: "Space not found" });
        }
        
        if (space.availableSeats <= 0) {
          return res.status(400).json({ message: "No available seats at this space" });
        }
        
        const booking = await storage.createBooking(bookingData);
        
        res.status(201).json(booking);
      } catch (error) {
        if (error instanceof ZodError) {
          return res.status(400).json({ message: "Invalid booking data", errors: error.errors });
        }
        throw error;
      }
    } catch (error) {
      next(error);
    }
  });

  // Cancel a booking
  app.post("/api/bookings/:id/cancel", isAuthenticated, async (req, res, next) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid booking ID" });
      }
      
      const booking = await storage.getBookingById(id);
      if (!booking) {
        return res.status(404).json({ message: "Booking not found" });
      }
      
      if (booking.userId !== req.user!.id) {
        return res.status(403).json({ message: "Not authorized to cancel this booking" });
      }
      
      const success = await storage.cancelBooking(id);
      if (!success) {
        return res.status(500).json({ message: "Failed to cancel booking" });
      }
      
      res.json({ message: "Booking cancelled successfully" });
    } catch (error) {
      next(error);
    }
  });

  // Get user favorites
  app.get("/api/favorites", isAuthenticated, async (req, res, next) => {
    try {
      const userId = req.user!.id;
      const favorites = await storage.getFavorites(userId);
      
      // Enhance favorites with space details
      const enhancedFavorites = await Promise.all(favorites.map(async (favorite) => {
        const space = await storage.getSpaceById(favorite.spaceId);
        return {
          ...favorite,
          space
        };
      }));
      
      res.json(enhancedFavorites);
    } catch (error) {
      next(error);
    }
  });

  // Add to favorites
  app.post("/api/favorites", isAuthenticated, async (req, res, next) => {
    try {
      const userId = req.user!.id;
      
      // Validate request body
      try {
        const favoriteData = insertFavoriteSchema.parse({
          ...req.body,
          userId
        });
        
        // Check if space exists
        const space = await storage.getSpaceById(favoriteData.spaceId);
        if (!space) {
          return res.status(404).json({ message: "Space not found" });
        }
        
        const favorite = await storage.addFavorite(favoriteData);
        
        res.status(201).json(favorite);
      } catch (error) {
        if (error instanceof ZodError) {
          return res.status(400).json({ message: "Invalid favorite data", errors: error.errors });
        }
        throw error;
      }
    } catch (error) {
      next(error);
    }
  });

  // Remove from favorites
  app.delete("/api/favorites/:spaceId", isAuthenticated, async (req, res, next) => {
    try {
      const userId = req.user!.id;
      const spaceId = parseInt(req.params.spaceId);
      
      if (isNaN(spaceId)) {
        return res.status(400).json({ message: "Invalid space ID" });
      }
      
      const success = await storage.removeFavorite(userId, spaceId);
      if (!success) {
        return res.status(404).json({ message: "Favorite not found" });
      }
      
      res.json({ message: "Removed from favorites" });
    } catch (error) {
      next(error);
    }
  });

  // Update space availability
  app.patch("/api/spaces/:id/availability", async (req, res, next) => {
    try {
      const id = parseInt(req.params.id);
      const { availableSeats } = req.body;
      
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid space ID" });
      }
      
      if (typeof availableSeats !== 'number' || availableSeats < 0) {
        return res.status(400).json({ message: "Available seats must be a positive number" });
      }
      
      const updatedSpace = await storage.updateSpaceAvailability(id, availableSeats);
      if (!updatedSpace) {
        return res.status(404).json({ message: "Space not found" });
      }
      
      res.json(updatedSpace);
    } catch (error) {
      next(error);
    }
  });

  // Search spaces by query
  app.get("/api/search", async (req, res, next) => {
    try {
      const { query, type } = req.query;
      
      if (!query) {
        return res.status(400).json({ message: "Search query is required" });
      }
      
      // Get all spaces, then filter by query
      let spaces = await storage.getSpaces();
      
      // Filter by type if provided
      if (type) {
        spaces = spaces.filter(space => space.type === type);
      }
      
      // Simple search by name or description containing the query string
      const searchTerm = (query as string).toLowerCase();
      const results = spaces.filter(space => 
        space.name.toLowerCase().includes(searchTerm) || 
        (space.description ? space.description.toLowerCase().includes(searchTerm) : false) ||
        (space.amenities ? space.amenities.some(amenity => amenity.toLowerCase().includes(searchTerm)) : false)
      );
      
      res.json(results);
    } catch (error) {
      next(error);
    }
  });

  // Get spaces near a location (simple version without actual geo search)
  app.get("/api/spaces/nearby", async (req, res, next) => {
    try {
      const { latitude, longitude, radius } = req.query;
      
      // Simple validation
      if (!latitude || !longitude) {
        return res.status(400).json({ message: "Latitude and longitude are required" });
      }
      
      const lat = parseFloat(latitude as string);
      const lng = parseFloat(longitude as string);
      const rad = radius ? parseFloat(radius as string) : 5; // Default 5km radius
      
      if (isNaN(lat) || isNaN(lng) || isNaN(rad)) {
        return res.status(400).json({ message: "Invalid location parameters" });
      }
      
      // Get all spaces
      const allSpaces = await storage.getSpaces();
      
      // Simple distance calculation (not accurate for large distances)
      // For a real app, we would use a proper geo library or database geo functions
      const nearbySpaces = allSpaces.filter(space => {
        // Skip spaces without coordinates
        if (!space.latitude || !space.longitude) return false;
        
        // Simple Euclidean distance (not accurate for real geo, but good for demo)
        const spaceLat = parseFloat(space.latitude);
        const spaceLng = parseFloat(space.longitude);
        const distance = Math.sqrt(
          Math.pow((spaceLat - lat) * 111.32, 2) + 
          Math.pow((spaceLng - lng) * 111.32 * Math.cos(lat * Math.PI/180), 2)
        );
        
        return distance <= rad;
      }).map(space => ({
        ...space,
        distance: Math.sqrt(
          Math.pow((parseFloat(space.latitude!) - lat) * 111.32, 2) + 
          Math.pow((parseFloat(space.longitude!) - lng) * 111.32 * Math.cos(lat * Math.PI/180), 2)
        ).toFixed(1)
      }));
      
      // Sort by distance
      nearbySpaces.sort((a, b) => parseFloat(a.distance) - parseFloat(b.distance));
      
      res.json(nearbySpaces);
    } catch (error) {
      next(error);
    }
  });

  // Get recommendations based on user preferences
  app.get("/api/recommendations", isAuthenticated, async (req, res, next) => {
    try {
      const userId = req.user!.id;
      
      // Get user's favorites to base recommendations on
      const favorites = await storage.getFavorites(userId);
      
      // If user has no favorites, return popular spaces
      if (favorites.length === 0) {
        const allSpaces = await storage.getSpaces();
        
        // For demo, just return a few random spaces as "popular"
        const popularSpaces = allSpaces
          .sort(() => 0.5 - Math.random())
          .slice(0, 5);
        
        return res.json({
          type: "popular",
          spaces: popularSpaces
        });
      }
      
      // Get all spaces
      const allSpaces = await storage.getSpaces();
      
      // Get user's favorite space types
      const favoriteSpaceIds = favorites.map(fav => fav.spaceId);
      const favoriteSpaces = await Promise.all(
        favoriteSpaceIds.map(id => storage.getSpaceById(id))
      );
      
      // Filter out undefined spaces
      const validFavoriteSpaces = favoriteSpaces.filter(space => space !== undefined) as any[];
      
      // Get the most common type among favorites
      const typeCount: Record<string, number> = {};
      validFavoriteSpaces.forEach(space => {
        typeCount[space.type] = (typeCount[space.type] || 0) + 1;
      });
      
      // Find most frequent type
      let mostFrequentType = "";
      let maxCount = 0;
      
      Object.entries(typeCount).forEach(([type, count]) => {
        if (count > maxCount) {
          maxCount = count;
          mostFrequentType = type;
        }
      });
      
      // Filter spaces by the most frequent type and exclude already favorited spaces
      const recommendedSpaces = allSpaces
        .filter(space => 
          space.type === mostFrequentType && 
          !favoriteSpaceIds.includes(space.id)
        )
        .slice(0, 5); // Limit to 5 recommendations
      
      res.json({
        type: "personalized",
        based_on: mostFrequentType,
        spaces: recommendedSpaces
      });
    } catch (error) {
      next(error);
    }
  });

  // Rating endpoints
  // Get all ratings for a space
  app.get("/api/spaces/:id/ratings", async (req, res, next) => {
    try {
      const spaceId = parseInt(req.params.id);
      
      if (isNaN(spaceId)) {
        return res.status(400).json({ message: "Invalid space ID" });
      }
      
      const space = await storage.getSpaceById(spaceId);
      if (!space) {
        return res.status(404).json({ message: "Space not found" });
      }
      
      const ratings = await storage.getRatingsBySpaceId(spaceId);
      
      // Enhance with user information
      const enhancedRatings = await Promise.all(ratings.map(async (rating: Rating) => {
        const user = await storage.getUser(rating.userId);
        return {
          ...rating,
          username: user ? user.username : 'Anonymous'
        };
      }));
      
      res.json(enhancedRatings);
    } catch (error) {
      next(error);
    }
  });
  
  // Add a rating for a space
  app.post("/api/spaces/:id/ratings", isAuthenticated, async (req, res, next) => {
    try {
      const userId = req.user!.id;
      const spaceId = parseInt(req.params.id);
      
      if (isNaN(spaceId)) {
        return res.status(400).json({ message: "Invalid space ID" });
      }
      
      // Check if space exists
      const space = await storage.getSpaceById(spaceId);
      if (!space) {
        return res.status(404).json({ message: "Space not found" });
      }
      
      // Validate request body
      try {
        const ratingData = insertRatingSchema.parse({
          ...req.body,
          userId,
          spaceId
        });
        
        // Validate rating value
        if (ratingData.rating < 1 || ratingData.rating > 5) {
          return res.status(400).json({ message: "Rating must be between 1 and 5" });
        }
        
        // Check if user already rated this space
        const existingRating = await storage.getRatingByUserAndSpace(userId, spaceId);
        
        let rating;
        if (existingRating) {
          // Update existing rating
          rating = await storage.updateRating(existingRating.id, ratingData);
        } else {
          // Create new rating
          rating = await storage.createRating(ratingData);
        }
        
        // Update average rating for the space
        await storage.updateSpaceAverageRating(spaceId);
        
        res.status(201).json(rating);
      } catch (error) {
        if (error instanceof ZodError) {
          return res.status(400).json({ message: "Invalid rating data", errors: error.errors });
        }
        throw error;
      }
    } catch (error) {
      next(error);
    }
  });
  
  // Delete a rating
  app.delete("/api/ratings/:id", isAuthenticated, async (req, res, next) => {
    try {
      const userId = req.user!.id;
      const ratingId = parseInt(req.params.id);
      
      if (isNaN(ratingId)) {
        return res.status(400).json({ message: "Invalid rating ID" });
      }
      
      // Check if rating exists and belongs to user
      const rating = await storage.getRatingById(ratingId);
      if (!rating) {
        return res.status(404).json({ message: "Rating not found" });
      }
      
      if (rating.userId !== userId) {
        return res.status(403).json({ message: "Not authorized to delete this rating" });
      }
      
      const success = await storage.deleteRating(ratingId);
      if (!success) {
        return res.status(500).json({ message: "Failed to delete rating" });
      }
      
      // Update average rating for the space
      await storage.updateSpaceAverageRating(rating.spaceId);
      
      res.json({ message: "Rating deleted successfully" });
    } catch (error) {
      next(error);
    }
  });

  // Create HTTP server
  const httpServer = createServer(app);
  
  // Setup WebSocket server
  setupWebsocket(httpServer);

  return httpServer;
}
