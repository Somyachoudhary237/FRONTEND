import { 
  users, type User, type InsertUser,
  spaces, type Space, type InsertSpace,
  bookings, type Booking, type InsertBooking,
  favorites, type Favorite, type InsertFavorite,
  ratings, type Rating, type InsertRating
} from "@shared/schema";
import session from "express-session";
import createMemoryStore from "memorystore";

const MemoryStore = createMemoryStore(session);

// Interface for storage operations
export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Space operations
  getSpaces(): Promise<Space[]>;
  getSpaceById(id: number): Promise<Space | undefined>;
  getSpacesByType(type: string): Promise<Space[]>;
  createSpace(space: InsertSpace): Promise<Space>;
  updateSpaceAvailability(id: number, seats: number): Promise<Space | undefined>;
  
  // Booking operations
  getBookings(userId: number): Promise<Booking[]>;
  getBookingById(id: number): Promise<Booking | undefined>;
  createBooking(booking: InsertBooking): Promise<Booking>;
  cancelBooking(id: number): Promise<boolean>;
  
  // Favorites operations
  getFavorites(userId: number): Promise<Favorite[]>;
  addFavorite(favorite: InsertFavorite): Promise<Favorite>;
  removeFavorite(userId: number, spaceId: number): Promise<boolean>;
  
  // Rating operations
  getRatingsBySpaceId(spaceId: number): Promise<Rating[]>;
  getRatingById(id: number): Promise<Rating | undefined>;
  getRatingByUserAndSpace(userId: number, spaceId: number): Promise<Rating | undefined>;
  createRating(rating: InsertRating): Promise<Rating>;
  updateRating(id: number, rating: InsertRating): Promise<Rating>;
  deleteRating(id: number): Promise<boolean>;
  updateSpaceAverageRating(spaceId: number): Promise<void>;
  
  // Session store
  sessionStore: any; // Using any for SessionStore to avoid type conflicts
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private spaces: Map<number, Space>;
  private bookings: Map<number, Booking>;
  private favorites: Map<number, Favorite>;
  private ratings: Map<number, Rating>;
  sessionStore: any;
  
  private userId: number = 1;
  private spaceId: number = 1;
  private bookingId: number = 1;
  private favoriteId: number = 1;
  private ratingId: number = 1;

  constructor() {
    this.users = new Map();
    this.spaces = new Map();
    this.bookings = new Map();
    this.favorites = new Map();
    this.ratings = new Map();
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000, // Clear expired sessions once per day
    });
    this.initializeSpaces();
  }

  // Initialize with some study spaces
  private initializeSpaces() {
    const sampleSpaces: InsertSpace[] = [
      {
        name: "Central Public Library",
        type: "library",
        address: "123 Main St",
        description: "A quiet, spacious library with ample natural light and various study sections. Perfect for long study sessions.",
        imageUrl: "https://images.unsplash.com/photo-1481627834876-b7833e8f5570",
        latitude: "20.5937",
        longitude: "78.9629",
        totalSeats: 120,
        availableSeats: 44,
        rating: 5,
        openingTime: "9:00 AM",
        closingTime: "9:00 PM",
        hasWifi: true,
        hasQuietZone: true,
        hasPower: true,
        hasGroupSpace: false,
        amenities: ["Free Wi-Fi", "Quiet Zones", "Research Materials", "Printing Services", "Study Desks"]
      },
      {
        name: "Brew & Study Cafe",
        type: "cafe",
        address: "456 Park Ave",
        description: "Cozy cafe with artisan coffee and dedicated study areas. Ambient music and great food make it a favorite for students.",
        imageUrl: "https://images.unsplash.com/photo-1445116572660-236099ec97a0",
        latitude: "20.5937",
        longitude: "78.9639",
        totalSeats: 40,
        availableSeats: 0,
        rating: 4,
        openingTime: "8:00 AM",
        closingTime: "10:00 PM",
        hasWifi: true,
        hasQuietZone: false,
        hasPower: true,
        hasGroupSpace: true,
        amenities: ["Free Wi-Fi", "Coffee & Snacks", "Group Tables", "Power Outlets", "Weekend Events"]
      },
      {
        name: "DAVV University Study Hall",
        type: "university",
        address: "789 Campus Drive",
        description: "Spacious academic hall with 24/7 access for students. Provides a distraction-free environment for serious studying.",
        imageUrl: "https://images.unsplash.com/photo-1523050854058-8df90110c9f1",
        latitude: "20.5947",
        longitude: "78.9629",
        totalSeats: 200,
        availableSeats: 78,
        rating: 5,
        openingTime: "24/7",
        closingTime: "",
        hasWifi: true,
        hasQuietZone: true,
        hasPower: true,
        hasGroupSpace: false,
        amenities: ["Wi-Fi", "24/7 Access", "Charging Stations", "Water Dispensers", "Student Support"]
      },
      {
        name: "Lakeside Study Pavilion",
        type: "outdoor",
        address: "202 Lakeview Park",
        description: "Open-air pavilion with beautiful lake views, providing a refreshing study environment with natural surroundings.",
        imageUrl: "https://images.unsplash.com/photo-1600939156080-d45746492ce9",
        latitude: "20.5950",
        longitude: "78.9650",
        totalSeats: 30,
        availableSeats: 12,
        rating: 4,
        openingTime: "8:00 AM",
        closingTime: "6:00 PM",
        hasWifi: true,
        hasQuietZone: false,
        hasPower: false,
        hasGroupSpace: true,
        amenities: ["Natural Light", "Scenic Views", "Outdoor Seating", "Wi-Fi Hotspots", "Walking Trails"]
      },
      {
        name: "Collaborative Learning Center",
        type: "study_room",
        address: "505 Innovation Blvd",
        description: "Modern group study rooms designed for collaboration and brainstorming sessions with smart boards and flexible seating.",
        imageUrl: "https://images.unsplash.com/photo-1522071820081-009f0129c71c",
        latitude: "20.5960",
        longitude: "78.9660",
        totalSeats: 48,
        availableSeats: 24,
        rating: 5,
        openingTime: "9:00 AM",
        closingTime: "10:00 PM",
        hasWifi: true,
        hasQuietZone: false,
        hasPower: true,
        hasGroupSpace: true,
        amenities: ["Smart Boards", "Group Tables", "Presentation Equipment", "Private Rooms", "Catering Available"]
      }
    ];

    sampleSpaces.forEach(space => this.createSpace(space));
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userId++;
    const now = new Date();
    const user: User = { ...insertUser, id, createdAt: now };
    this.users.set(id, user);
    return user;
  }

  // Space operations
  async getSpaces(): Promise<Space[]> {
    return Array.from(this.spaces.values());
  }

  async getSpaceById(id: number): Promise<Space | undefined> {
    return this.spaces.get(id);
  }

  async getSpacesByType(type: string): Promise<Space[]> {
    return Array.from(this.spaces.values()).filter(
      (space) => space.type === type,
    );
  }

  async createSpace(insertSpace: InsertSpace): Promise<Space> {
    const id = this.spaceId++;
    const space: Space = { ...insertSpace, id };
    this.spaces.set(id, space);
    return space;
  }

  async updateSpaceAvailability(id: number, seats: number): Promise<Space | undefined> {
    const space = this.spaces.get(id);
    if (!space) return undefined;
    
    const updatedSpace: Space = {
      ...space,
      availableSeats: seats
    };
    
    this.spaces.set(id, updatedSpace);
    return updatedSpace;
  }

  // Booking operations
  async getBookings(userId: number): Promise<Booking[]> {
    return Array.from(this.bookings.values()).filter(
      (booking) => booking.userId === userId,
    );
  }

  async getBookingById(id: number): Promise<Booking | undefined> {
    return this.bookings.get(id);
  }

  async createBooking(insertBooking: InsertBooking): Promise<Booking> {
    const id = this.bookingId++;
    const now = new Date();
    const booking: Booking = { ...insertBooking, id, createdAt: now };
    
    this.bookings.set(id, booking);
    
    // Update space availability
    const space = this.spaces.get(booking.spaceId);
    if (space && space.availableSeats > 0) {
      await this.updateSpaceAvailability(booking.spaceId, space.availableSeats - 1);
    }
    
    return booking;
  }

  async cancelBooking(id: number): Promise<boolean> {
    const booking = this.bookings.get(id);
    if (!booking) return false;
    
    booking.status = "cancelled";
    this.bookings.set(id, booking);
    
    // Update space availability
    const space = this.spaces.get(booking.spaceId);
    if (space) {
      await this.updateSpaceAvailability(booking.spaceId, space.availableSeats + 1);
    }
    
    return true;
  }

  // Favorites operations
  async getFavorites(userId: number): Promise<Favorite[]> {
    return Array.from(this.favorites.values()).filter(
      (favorite) => favorite.userId === userId,
    );
  }

  async addFavorite(insertFavorite: InsertFavorite): Promise<Favorite> {
    const id = this.favoriteId++;
    const now = new Date();
    const favorite: Favorite = { ...insertFavorite, id, createdAt: now };
    this.favorites.set(id, favorite);
    return favorite;
  }

  async removeFavorite(userId: number, spaceId: number): Promise<boolean> {
    const favorite = Array.from(this.favorites.values()).find(
      (fav) => fav.userId === userId && fav.spaceId === spaceId,
    );
    
    if (!favorite) return false;
    
    this.favorites.delete(favorite.id);
    return true;
  }

  // Rating operations
  async getRatingsBySpaceId(spaceId: number): Promise<Rating[]> {
    return Array.from(this.ratings.values()).filter(
      (rating) => rating.spaceId === spaceId
    );
  }

  async getRatingById(id: number): Promise<Rating | undefined> {
    return this.ratings.get(id);
  }

  async getRatingByUserAndSpace(userId: number, spaceId: number): Promise<Rating | undefined> {
    return Array.from(this.ratings.values()).find(
      (rating) => rating.userId === userId && rating.spaceId === spaceId
    );
  }

  async createRating(insertRating: InsertRating): Promise<Rating> {
    const id = this.ratingId++;
    const now = new Date();
    const rating: Rating = { ...insertRating, id, createdAt: now };
    
    this.ratings.set(id, rating);
    
    // Update space average rating
    await this.updateSpaceAverageRating(rating.spaceId);
    
    return rating;
  }

  async updateRating(id: number, data: InsertRating): Promise<Rating> {
    const rating = this.ratings.get(id);
    if (!rating) {
      throw new Error('Rating not found');
    }
    
    const updatedRating: Rating = {
      ...rating,
      rating: data.rating,
      comment: data.comment,
      userId: data.userId,
      spaceId: data.spaceId
    };
    
    this.ratings.set(id, updatedRating);
    
    // Update space average rating
    await this.updateSpaceAverageRating(updatedRating.spaceId);
    
    return updatedRating;
  }

  async deleteRating(id: number): Promise<boolean> {
    const rating = this.ratings.get(id);
    if (!rating) return false;
    
    this.ratings.delete(id);
    
    // Update space average rating
    await this.updateSpaceAverageRating(rating.spaceId);
    
    return true;
  }

  async updateSpaceAverageRating(spaceId: number): Promise<void> {
    const space = this.spaces.get(spaceId);
    if (!space) return;
    
    const ratings = await this.getRatingsBySpaceId(spaceId);
    
    if (ratings.length === 0) {
      // If no ratings, set default rating
      space.rating = 0;
    } else {
      // Calculate average rating
      const sum = ratings.reduce((total, rating) => total + rating.rating, 0);
      space.rating = Math.round((sum / ratings.length) * 10) / 10; // Round to 1 decimal place
    }
    
    this.spaces.set(spaceId, space);
  }
}

export const storage = new MemStorage();
