import { WebSocketServer, WebSocket } from 'ws';
import { Server } from 'http';
import { storage } from './storage';

// Type for WebSocket messages
interface WSMessage {
  type: string;
  data: any;
}

export function setupWebsocket(server: Server) {
  const wss = new WebSocketServer({ server, path: '/ws' });
  
  wss.on('connection', (ws) => {
    console.log('WebSocket client connected');
    
    // Send all spaces when a client connects
    sendSpaces(ws);
    
    ws.on('message', async (message) => {
      try {
        const parsedMessage: WSMessage = JSON.parse(message.toString());
        
        if (parsedMessage.type === 'UPDATE_AVAILABILITY') {
          const { spaceId, availableSeats } = parsedMessage.data;
          await handleAvailabilityUpdate(spaceId, availableSeats);
          broadcastSpaces(wss);
        }
      } catch (error) {
        console.error('Error processing WebSocket message:', error);
      }
    });
    
    ws.on('close', () => {
      console.log('WebSocket client disconnected');
    });
  });
  
  return wss;
}

// Send current spaces data to a specific client
async function sendSpaces(ws: WebSocket) {
  try {
    if (ws.readyState === WebSocket.OPEN) {
      const spaces = await storage.getSpaces();
      ws.send(JSON.stringify({
        type: 'SPACES_UPDATE',
        data: spaces
      }));
    }
  } catch (error) {
    console.error('Error sending spaces to client:', error);
  }
}

// Broadcast spaces data to all connected clients
async function broadcastSpaces(wss: WebSocketServer) {
  try {
    const spaces = await storage.getSpaces();
    wss.clients.forEach((client) => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(JSON.stringify({
          type: 'SPACES_UPDATE',
          data: spaces
        }));
      }
    });
  } catch (error) {
    console.error('Error broadcasting spaces:', error);
  }
}

// Handle availability update
async function handleAvailabilityUpdate(spaceId: number, availableSeats: number) {
  try {
    await storage.updateSpaceAvailability(spaceId, availableSeats);
  } catch (error) {
    console.error('Error updating space availability:', error);
  }
}
