import { Switch, Route, useLocation } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { AnimatePresence } from "framer-motion";
import NotFound from "@/pages/not-found";
import HomePage from "@/pages/home-page";
import AuthPage from "@/pages/auth-page";
import SpacesPage from "@/pages/spaces-page";
import BookingsPage from "@/pages/bookings-page";
import FavoritesPage from "@/pages/favorites-page";
import ContactPage from "@/pages/contact-page";
import HelpCenterPage from "@/pages/help-center-page";
import AboutPage from "@/pages/about-page";
import PreferencesPage from "@/pages/preferences-page";
import LibrariesPage from "@/pages/libraries-page";
import StudyRoomsPage from "@/pages/study-rooms-page";
import { AuthProvider } from "@/hooks/use-auth";
import { WebSocketProvider } from "@/hooks/use-websocket";
import { ProtectedRoute } from "./lib/protected-route";

function Router() {
  const [location] = useLocation();
  
  return (
      <Switch>
        <Route path="/" component={HomePage} />
        <Route path="/auth" component={AuthPage} />
        <Route path="/spaces" component={SpacesPage} />
        <Route path="/preferences" component={PreferencesPage} />
        <Route path="/libraries" component={LibrariesPage} />
        <Route path="/study-rooms" component={StudyRoomsPage} />
        <ProtectedRoute path="/bookings" component={BookingsPage} />
        <ProtectedRoute path="/favorites" component={FavoritesPage} />
        <Route path="/contact" component={ContactPage} />
        <Route path="/help" component={HelpCenterPage} />
        <Route path="/about" component={AboutPage} />
        <Route component={NotFound} />
      </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <WebSocketProvider>
          <Router />
          <Toaster />
        </WebSocketProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
